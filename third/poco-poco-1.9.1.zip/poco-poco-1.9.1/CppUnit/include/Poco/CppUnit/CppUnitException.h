//
// CppUnitException.h
//


#ifndef Poco_CppUnit_CppUnitException_INCLUDED
#define Poco_CppUnit_CppUnitException_INCLUDED

#include "CppUnit/CppUnitException.h"

#endif // Poco_CppUnit_CppUnitException_INCLUDED
